import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import 'mdbreact/dist/css/mdb.css';
import './index.css';

ReactDOM.render(
    <App />,
  document.getElementById('root')
);

