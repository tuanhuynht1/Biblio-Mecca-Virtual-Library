import React, { Component } from 'react';
import axios from 'axios';
import CheckoutEntry from './CheckoutEntry';

class Checkouts extends Component {
	constructor(props) {
		super(props);
		this.state = {
			history: null,
		};
		this.onClickCheckin = this.onClickCheckin.bind(this);
	}

	componentDidMount() {
		axios
			.get(`/api/viewCheckoutHistory/${this.props.user}`)
			.then((res) => {
				console.log(res);
				this.setState({
					history: res.data,
				});
				// console.log(this.state.history);
			})
			.catch(console.error);
	}

	onClickCheckin(bid) {
		axios.get(`/api/checkinBook/${bid}`).then((res) => {
			axios.get(`/api/viewCheckoutHistory/${this.props.user}`).then((res) => {
				console.log(res);
				this.setState({
					history: res.data,
				});
			});
		}).catch(console.error);
	}

	render() {
		const { history } = this.state;
		// const style = {

		// }
		return (
			<div style={{ margin: '100px auto', width: '90%' }}>
				{history === null ? (
					<h3>One moment please ...</h3>
				) : (
					<table width={'100%'}>
						<tbody>
							<tr style={{ textAlign: 'center' }}>
								<td>
									<strong>Title</strong>
								</td>
								<td>
									<strong>Author</strong>
								</td>
								<td>
									<strong>ISBN</strong>
								</td>
								<td>
									<strong>Date Checked Out</strong>
								</td>
								<td>
									<strong>Date Checked In</strong>
								</td>
								<td>
									<strong>Check In</strong>
								</td>
							</tr>

							{history.length === 0 ? (
								<tr></tr>
							) : (
								history.map((checkout, i) => <CheckoutEntry key={i} checkout={checkout} onClickCheckin={this.onClickCheckin} />)
							)}
						</tbody>
					</table>
				)}
			</div>
		);
	}
}

export default Checkouts;
