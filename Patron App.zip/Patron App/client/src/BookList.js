import React from 'react';
import BookEntry from './BookEntry';

const BookList = ({ booklist, setIndex, selectedIndex }) => {
	return (
		<div style={{ margin: '20px auto', width: '950px', height: '320px' , overflowY: 'auto' }}>
			<table style={{width: '100%'}}>
				<tbody>
					<tr>
						<td>
							<strong>Title</strong>
						</td>
						<td>
							<strong>Author</strong>
						</td>
						<td>
							<strong>ISBN</strong>
						</td>
						<td>
							<strong>Format</strong>
						</td>
					</tr>
					{booklist.map( (book,i) => 
						<BookEntry book={book} i={i} setIndex={setIndex} key={book.isbn} 
						highlight={selectedIndex === i ? true : false}/>
					)}
				</tbody>
			</table>
		</div>
	);
};

export default BookList;
