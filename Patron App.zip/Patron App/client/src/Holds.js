import React, { Component } from 'react';
import axios from 'axios';
import HoldEntry from './HoldEntry';

class Holds extends Component {
	constructor(props) {
		super(props);
		this.state = {
			holds: null,
		};
	}

	componentDidMount() {
		axios
			.get(`api/checkMyHold/${this.props.user}`)
			.then((res) => {
				console.log(res);
				this.setState({
					holds: res.data,
				});
				console.log(this.state.holds);
			})
			.catch(console.error);
	}

	render() {
		const { holds } = this.state;

		return (
			<div style={{ margin: '100px auto', width: '90%' }}>
				{holds === null ? (
					<h3>One moment please ...</h3>
				) : (
					<table width={'100%'}>
						<tbody>
							<tr style={{ textAlign: 'center' }}>
								<td>
									<strong>Title</strong>
								</td>
								<td>
									<strong>Author</strong>
								</td>
								<td>
									<strong>ISBN</strong>
								</td>
								<td>
									<strong>Format</strong>
								</td>
								<td>
									<strong>Request Date</strong>
								</td>
								<td>
									<strong>Availability</strong>
								</td>
							</tr>

							{holds.length === 0 ? (
								<tr></tr>
							) : (
								holds.map((hold, i) => 
									<HoldEntry 
										switchContent={this.props.switchContent} 
										user={this.props.user}
										hold={hold} 
										key={i}/>)
							)}
						</tbody>
					</table>
				)}
			</div>
		);
	}
}

export default Holds;
