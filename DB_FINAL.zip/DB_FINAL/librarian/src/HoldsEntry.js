import React from 'react';

const HoldsEntry = ({ hold }) => {
	return (
		<tr>
			<td>{hold.username}</td>
			<td>{hold.title}</td>
			<td>{hold.isbn}</td>
			<td>{hold.request_on.substr(0,10)} {' '} {hold.request_on.substr(11,8)}</td>
			<td>{hold.available_on.substr(0,10)} {' '} {hold.available_on.substr(11,8)}</td>
			<td>{hold.bid}</td>
		</tr>
	);
};

export default HoldsEntry;
