const express = require('express');
const path = require('path');
const apiRouter = require('./api');

const server = express();
const port = 5000;


server.use('/api',apiRouter);

server.listen(port, ()=> console.log(`listening to port: ${port}`));

// server.use(express.static,path.join(__dirname,'client/build'));


