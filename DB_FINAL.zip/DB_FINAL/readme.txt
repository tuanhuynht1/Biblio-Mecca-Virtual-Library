inside root dir '/DB_FINAL/'
	open terminal
	run command: npm install	// install dependencies
	run command: npm start		// start express server

cd inside dir '/DB_FINAL/client/'
	open another terminal		
	run command: npm install	// install dependencies
	run command: npm start		// start Patron react app

cd inside dir '/DB_FINAL/librarian/'
	open another terminal		
	run command: npm install	// install dependencies
	run command: npm start		// start Librarian react app

* If you want to run both patron and librarian app simultaneously, 
  you need to have all 3 terminals running at the same time