import React from 'react';

const CheckoutEntry = ({checkout}) => {
	return (
		<tr>
			<td>{checkout.username}</td>
            <td>{checkout.title}</td>
            <td>{checkout.isbn}</td>
			<td>{checkout.check_out_date}</td>
			<td>{checkout.bid}</td>
		</tr>
	);
};  

export default CheckoutEntry;
